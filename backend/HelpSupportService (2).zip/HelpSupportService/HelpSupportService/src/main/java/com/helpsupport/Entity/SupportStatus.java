package com.helpsupport.Entity;

public enum SupportStatus {

	ACTIVE, RESOLVED, CLOSED
	
}
