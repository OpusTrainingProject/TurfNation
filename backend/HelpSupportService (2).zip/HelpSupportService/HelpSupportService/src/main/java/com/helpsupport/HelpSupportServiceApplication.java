package com.helpsupport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpSupportServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpSupportServiceApplication.class, args);
	}

}
