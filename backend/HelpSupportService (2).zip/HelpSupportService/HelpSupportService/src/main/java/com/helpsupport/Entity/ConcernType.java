package com.helpsupport.Entity;

public enum ConcernType {

	 BOOKING_RELATED, TURF_RELATED, PAYMENT_RELATED, OTHER

	
}
