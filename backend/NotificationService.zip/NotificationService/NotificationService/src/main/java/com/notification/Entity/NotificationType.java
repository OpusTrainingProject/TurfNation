package com.notification.Entity;

public enum NotificationType {
	
	  OTP,BOOKING_CONFIRMATION
}
