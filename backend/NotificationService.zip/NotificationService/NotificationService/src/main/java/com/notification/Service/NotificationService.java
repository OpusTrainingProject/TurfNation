package com.notification.Service;

import com.notification.Entity.NotificationRequest;

public interface NotificationService {

	void sendNotification(NotificationRequest request);
	
}
