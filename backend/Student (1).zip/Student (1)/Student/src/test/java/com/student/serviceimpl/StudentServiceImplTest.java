package com.student.serviceimpl;

import com.student.entity.Student;
import com.student.repo.StudentRepo;
import com.student.service.StudentService;
import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@ActiveProfiles("test")
class StudentServiceImplTest {

    @Mock
    private StudentRepo repo;

    @InjectMocks
    private StudentServiceImpl service; // your implementation class

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createShouldSaveWhenEmailUnique() {
        Student student = new Student("Riya", "riya@example.com");
        when(repo.findByEmail("riya@example.com")).thenReturn(Optional.empty());
        when(repo.save(student)).thenReturn(new Student("Riya", "riya@example.com"));

        Student saved = service.create(student);

        assertThat(saved.getName()).isEqualTo("Riya");
        verify(repo).save(student);
    }

    @Test
    void createShouldThrowWhenNameBlank() {
        Student student = new Student("", "riya@example.com");
        assertThatThrownBy(() -> service.create(student))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Name is required");
        verifyNoInteractions(repo);
    }

    @Test
    void getByIdShouldReturnWhenExists() {
        Student s = new Student("Riya", "riya@example.com");
        s.setId(1L);
        when(repo.findById(1L)).thenReturn(Optional.of(s));

        Student found = service.getById(1L);
        assertThat(found.getEmail()).isEqualTo("riya@example.com");
    }

    @Test
    void getByIdShouldThrowWhenMissing() {
        when(repo.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getById(99L))
                .isInstanceOf(NoSuchElementException.class)
                .hasMessageContaining("Student not found");
    }

    @Test
    void updateShouldChangeNameAndEmailWhenUnique() {
        Student existing = new Student("Old", "old@example.com");
        existing.setId(1L);
        when(repo.findById(1L)).thenReturn(Optional.of(existing));
        when(repo.findByEmail("new@example.com")).thenReturn(Optional.empty());

        Student updated = new Student("New", "new@example.com");
        Student saved = new Student("New", "new@example.com");
        saved.setId(1L);
        when(repo.save(any(Student.class))).thenReturn(saved);

        Student result = service.update(1L, updated);

        assertThat(result.getName()).isEqualTo("New");
        assertThat(result.getEmail()).isEqualTo("new@example.com");
        verify(repo).save(existing);
    }

    @Test
    void deleteShouldCallRepoWhenExists() {
        when(repo.existsById(1L)).thenReturn(true);
        service.delete(1L);
        verify(repo).deleteById(1L);
    }

    @Test
    void allEmailsShouldReturnMappedList() {
        when(repo.findAll()).thenReturn(List.of(
                new Student("A", "a@x.com"),
                new Student("B", "b@x.com")
        ));
        List<String> emails = service.allEmails();
        assertThat(emails).containsExactlyInAnyOrder("a@x.com", "b@x.com");
    }
}

