
package com.student.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.student.entity.Student;
import com.student.service.StudentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Pure unit test for StudentController using standalone MockMvc.
 * No Spring context, no @MockBean — we manually mock the StudentService.
 */
class StudentControllerUnitTest {

    private MockMvc mvc;
    private ObjectMapper objectMapper;
    private StudentService service; // manually mocked

    @BeforeEach
    void setup() {
        // Create a Mockito mock for the service
        service = Mockito.mock(StudentService.class);

        // Build MockMvc in standalone mode with the controller wired to the mock
        StudentController controller = new StudentController(service);
        mvc = MockMvcBuilders.standaloneSetup(controller).build();

        // Simple ObjectMapper for JSON serialization
        objectMapper = new ObjectMapper();
    }

    @Test
    void createShouldReturnStudent() throws Exception {
        Student input = new Student("Riya", "riya@example.com");
        Student output = new Student("Riya", "riya@example.com");
        output.setId(1L);

        Mockito.when(service.create(any(Student.class))).thenReturn(output);

        mvc.perform(post("/api/students")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Riya"))
                .andExpect(jsonPath("$.email").value("riya@example.com"));
    }

    private Student any(Class<Student> studentClass) {
        return null;
    }

    @Test
    void getAllShouldReturnList() throws Exception {
        Student s1 = new Student("Riya", "riya@example.com"); s1.setId(1L);
        Student s2 = new Student("Amit", "amit@example.com"); s2.setId(2L);

        Mockito.when(service.getAll()).thenReturn(List.of(s1, s2));

        mvc.perform(get("/api/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].name", is("Riya")))
                .andExpect(jsonPath("$[1].email", is("amit@example.com")));
    }

    @Test
    void updateShouldReturnUpdated() throws Exception {
        Student updated = new Student("Riya Sharma", "riya.sharma@example.com");
        Student out = new Student("Riya Sharma", "riya.sharma@example.com"); out.setId(1L);

        Mockito.when(service.update(eq(1L), any(Student.class))).thenReturn(out);

        mvc.perform(put("/api/students/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Riya Sharma"))
                .andExpect(jsonPath("$.email").value("riya.sharma@example.com"));
    }

    @Test
    void deleteShouldReturnNoContent() throws Exception {
        // No return value to stub; just verify interaction afterwards
        mvc.perform(delete("/api/students/1"))
                .andExpect(status().isNoContent());

        Mockito.verify(service).delete(1L);
    }

    @Test
    void searchShouldReturnMatches() throws Exception {
        Student s = new Student("Riya", "riya@example.com"); s.setId(1L);
        Mockito.when(service.searchByName("riya")).thenReturn(List.of(s));

        mvc.perform(get("/api/students/search").param("name", "riya"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Riya"));
    }
}
