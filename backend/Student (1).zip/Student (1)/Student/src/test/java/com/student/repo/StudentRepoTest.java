package com.student.repo;




import com.student.entity.Student;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@ActiveProfiles("test")
class StudentRepoTest {

    @Autowired
    private StudentRepo repo;

    @Test
    @DisplayName("save and findByEmail should work")
    void saveAndFindByEmail() {
        Student s = new Student("Riya", "riya@example.com");
        Student saved = repo.save(s);

        Optional<Student> byEmail = repo.findByEmail("riya@example.com");
        assertThat(byEmail).isPresent();
        assertThat(byEmail.get().getId()).isEqualTo(saved.getId());
        assertThat(byEmail.get().getName()).isEqualTo("Riya");
    }

    @Test
    @DisplayName("findByNameIgnoreCase should match case-insensitively")
    void findByNameIgnoreCase() {
        repo.save(new Student("Riya", "riya@example.com"));
        repo.save(new Student("RIYA", "riya2@example.com"));

        List<Student> results = repo.findByNameIgnoreCase("riya");
        assertThat(results).hasSize(2);
        assertThat(results).extracting(Student::getEmail)
                .containsExactlyInAnyOrder("riya@example.com", "riya2@example.com");
    }
}

