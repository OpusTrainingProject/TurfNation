package com.student.serviceimpl;


import com.student.entity.Student;
import com.student.repo.StudentRepo;
import com.student.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

    @Autowired
    private final StudentRepo repo;

    public StudentServiceImpl(StudentRepo repo) {
        this.repo = repo;
        // Constructor injection keeps it testable and avoids field injection issues
    }

    @Override
    public Student create(Student student) {
        // Basic null checks (since we removed global handler, fail fast here)
        if (student == null) {
            throw new IllegalArgumentException("Student body must not be null");
        }
        if (student.getName() == null || student.getName().isBlank()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (student.getEmail() == null || student.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }

        // Enforce unique email
        repo.findByEmail(student.getEmail()).ifPresent(existing -> {
            throw new IllegalArgumentException("Email already exists: " + existing.getEmail());
        });

        return repo.save(student);
    }

    @Override
    @Transactional(readOnly = true)
    public Student getById(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must not be null");
        }
        return repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Student not found: id=" + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Student> getAll() {
        // Use stream to sort by Name then email (both case-insensitive)
        return repo.findAll().stream()
                .sorted(Comparator
                        .comparing(Student::getName, String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(Student::getEmail, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    @Override
    public Student update(Long id, Student updated) {
        if (id == null) {
            throw new IllegalArgumentException("Id must not be null");
        }
        if (updated == null) {
            throw new IllegalArgumentException("Updated student must not be null");
        }

        Student existing = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Student not found: id=" + id));

        // Email uniqueness if changed
        if (updated.getEmail() != null && !updated.getEmail().isBlank()
                && !updated.getEmail().equalsIgnoreCase(existing.getEmail())) {
            repo.findByEmail(updated.getEmail()).ifPresent(e -> {
                throw new IllegalArgumentException("Email already exists: " + e.getEmail());
            });
            existing.setEmail(updated.getEmail());
        }

        // Update Name if provided
        if (updated.getName() != null && !updated.getName().isBlank()) {
            existing.setName(updated.getName());
        }

        return repo.save(existing);
    }

    @Override
    public void delete(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must not be null");
        }
        if (!repo.existsById(id)) {
            throw new NoSuchElementException("Student not found: id=" + id);
        }
        repo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Student> searchByName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Search name must not be blank");
        }
        // Repository + small lambda filter
        return repo.findByNameIgnoreCase(name).stream()
                .filter(s -> s.getName() != null) // defensive check
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> allEmails() {
        // Streams: map to email list (may contain nulls if DB has bad data; filter them out)
        return repo.findAll().stream()
                .map(Student::getEmail)
                .filter(e -> e != null && !e.isBlank())
                .toList();
    }
}
