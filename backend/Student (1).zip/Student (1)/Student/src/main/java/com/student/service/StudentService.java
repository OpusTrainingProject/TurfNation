package com.student.service;


import com.student.entity.Student;

import java.util.List;

public interface StudentService {


    Student create(Student student);
    Student getById(Long id);
    List<Student> getAll();
    Student update(Long id, Student updated);
    void delete(Long id);

    List<Student> searchByName(String name);
    List<String> allEmails();
    // uses streams to map

}

