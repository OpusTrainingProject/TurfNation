package com.student.repo;

import com.student.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

public interface StudentRepo extends JpaRepository<Student, Long> {


    Optional<Student> findByEmail(String email);

    // Case-insensitive name search (uses your "Name" field)
    List<Student> findByNameIgnoreCase(String name);


}
